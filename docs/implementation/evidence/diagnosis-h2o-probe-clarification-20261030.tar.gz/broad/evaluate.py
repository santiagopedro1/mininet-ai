"""Declared probe-completeness prompt evaluation with no inference retries."""

import hashlib
import json
import shutil
import subprocess
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

import yaml

from examples.diamond_recovery.diagnosis import evaluate_runtime
from mininet_ai.compiler import compile_experiment
from mininet_ai.substrates import FakeSubstrateRuntime
from mininet_ai.transports.http import HttpxJsonTransport
from tests.agents.test_bounded_evidence_schemas import validators

ENDPOINT = "http://10.10.10.152:9931"
MODEL = "h2oai/h2o-lightning-4b"
TRIALS = (
    "healthy",
    "missing-flow-s2",
    "s1-s2",
    "s2-s4",
    "missing-flow-s1",
    "missing-flow-s3",
    "missing-flow-s4",
    "missing-flow-first-s2",
    "missing-active-flow-s2",
    "missing-flow-same-count-s2",
    "wrong-flow-s2",
    "wrong-cookie-s2",
    "reordered-flows",
    "unavailable",
    "unavailable-flow",
    "unknown-port-s2",
    "missing-port-s2",
)
root = Path("/tmp/opencode") / (
    "diagnosis-h2o-probe-clarified-" + datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
)
root.mkdir(exist_ok=False)
shutil.copyfile(__file__, root / "evaluate.py")
native = HttpxJsonTransport()


class BudgetCheckedTransport:
    """Only refuse over-budget states; never change the payload or choose answers."""

    def get_json(self, url, **kwargs):
        return native.get_json(url, **kwargs)

    def post_json(self, url, payload, **kwargs):
        if not isinstance(payload.get("state"), str):
            raise ValueError("Retained canonical text state required; no inference sent")
        if len(payload["state"].encode("utf-8")) > 32000:
            raise ValueError("Native H2O state-cut safety bound exceeded; no inference sent")
        return native.post_json(url, payload, **kwargs)


def observe(route, filename):
    value = native.get_json(
        ENDPOINT + "/" + route,
        headers={"Accept": "application/json"},
        timeout_seconds=5,
        max_response_bytes=1_048_576,
    )
    (root / filename).write_text(
        json.dumps({"observedAt": datetime.now(UTC).isoformat(), "value": value}, indent=2)
        + "\n"
    )
    return value


def require_idle(filename):
    slots = observe("slots", filename)
    if not isinstance(slots, list) or len(slots) != 4 or any(
        slot.get("is_processing") is not False or slot.get("n_ctx") != 8192
        for slot in slots
    ):
        raise RuntimeError("Four idle 8192-context slots required; stop without retry")


print("Evidence:", root, flush=True)
require_idle("remote-preflight.json")
observe("health", "health.json")
props = observe("props", "props.json")
if props.get("model_alias") != MODEL or props.get("model_ftype") != "Q8_0":
    raise RuntimeError("Observed model or precision differs; no inference sent")
source = Path("examples/diamond-recovery/experiment.yaml")
document = yaml.safe_load(source.read_text())
model = document["blueprints"][0]["model"]
model["name"] = MODEL
model["parameters"] = {
    "endpoint": ENDPOINT,
    "expectedIdentity": {
        "repository": "h2oai/h2o-lightning-4b-gguf",
        "revision": "aba20a244eb1038b8546cd25c2d6046f0c3e4256",
        "artifact": "h2o-lightning-4b-Q8_0.gguf",
        "sha256": "4127b2ae7710c3864c21c3d946c316f28a654a53d3a4ba99f383bbcaf2768e81",
    },
}
(root / "experiment.yaml").write_text(yaml.safe_dump(document, sort_keys=False))
plan = compile_experiment(root / "experiment.yaml")
scenario = plan.agents[0].decision_scenario
assert scenario is not None
expectations = scenario["localExpectations"]
(root / "conditions.json").write_text(
    json.dumps(
        {
            "endpoint": ENDPOINT,
            "plannedTrials": TRIALS,
            "scope": "user-authorized prompt clarification; constructed local inputs, no OVS",
            "change": "instructions and choice descriptions explicitly require diagnostic-probe configuration; model, input shape, expectations, oracle and timing unchanged",
            "priorFailureArchive": "diagnosis-h2o-native-20261030.tar.gz",
            "evaluationLimit": "tuning after inspected missing-flow failure, not held-out validation",
            "sourceSHA256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "runnerCommit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
            "cadenceSeconds": 1,
            "deadlineSeconds": 5,
            "warmth": "startup-probed; cold unmeasured; server cache persists",
            "remoteHardware": "operator reports RTX3090 24576MiB total/17790MiB free VRAM and 114GiB available RAM; not independently verified or necessarily current",
            "remoteBackendAndActualLaunch": "unavailable; not independently observed",
            "requestedLaunch": "llama-server --model ~/models/h2o-lightning-4b-aba20a24/h2o-lightning-4b-Q8_0.gguf --alias h2oai/h2o-lightning-4b --no-mmproj --ctx-size 32768 --parallel 4 --host 10.10.10.152 --port 9931 --verbosity 4 --log-file <timestamped-path>",
            "artifactHashVerification": "expected publisher hash; operator said ready but did not separately provide checksum result; unconfirmed",
            "stateBudget": "byte length <=32000 guarded before each native POST; no state mutation or truncation",
            "retry": False,
            "stopOnFirstFailure": True,
        },
        indent=2,
    )
    + "\n"
)


class LocalSubstrate(FakeSubstrateRuntime):
    def __init__(self, trial):
        super().__init__()
        self.trial = trial

    def observe(self, run_id, query):
        result = super().observe(run_id, query)
        (target,) = query.targets
        local = deepcopy(expectations[target])
        if query.name == "ovs.port-state":
            if self.trial == "unavailable":
                return result.model_copy(update={"values": {target: None}})
            value = {"ports": [{"name": port, "state": "up"} for port in local["ports"]]}
            down = {
                "s1-s2": {"s1": "s1-eth2", "s2": "s2-eth1"},
                "s2-s4": {"s2": "s2-eth2", "s4": "s4-eth2"},
            }.get(self.trial, {})
            for port in value["ports"]:
                if port["name"] == down.get(target):
                    port["state"] = "down"
            if target == "s2":
                if self.trial == "unknown-port-s2":
                    value["ports"][0]["state"] = "unknown"
                if self.trial == "missing-port-s2":
                    value["ports"].pop()
        elif query.name == "openflow.flows":
            if self.trial == "unavailable-flow":
                return result.model_copy(update={"values": {target: None}})
            if self.trial == "missing-flow-" + target:
                local["flows"].pop()
            if target == "s2":
                if self.trial == "missing-flow-first-s2":
                    local["flows"].pop(0)
                if self.trial == "missing-active-flow-s2":
                    local["flows"].pop(1)
                if self.trial == "missing-flow-same-count-s2":
                    local["flows"][-1] = deepcopy(local["flows"][0])
                if self.trial == "wrong-flow-s2":
                    local["flows"][0]["actions"] = "NORMAL"
                if self.trial == "wrong-cookie-s2":
                    local["flows"][-1]["cookie"] = "0xdead"
            if self.trial == "reordered-flows":
                local["flows"].reverse()
            value = {"switches": [{"name": target, "flows": local["flows"]}]}
        else:
            raise RuntimeError(f"Unexpected observation {query.name}")
        return result.model_copy(update={"values": {target: value}})


_, validator = validators()
results = []
for trial in TRIALS:
    require_idle("remote-before-" + trial + ".json")
    try:
        summary = evaluate_runtime(
            plan, LocalSubstrate(trial), root / trial,
            decision_transport=BudgetCheckedTransport(),
        )
    finally:
        require_idle("remote-after-" + trial + ".json")
    rows = []
    for line in (root / trial / "invocations.jsonl").read_text().splitlines():
        record = json.loads(line)
        execution = record["result"]["response"]["metadata"]["executionRecord"]
        validator.validate(execution)
        decision = execution["runtime"]["boundedDecision"]
        rows.append(
            {
                "agent": record["agentId"],
                "status": record["result"]["status"],
                "choice": decision.get("selectedChoice"),
                "decisionSeconds": decision.get("timings", {}).get("decisionSeconds"),
                "stateBytes": len(decision["request"]["state"].encode("utf-8")),
                "issue": record["result"].get("issue"),
            }
        )
    result = {
        "trial": trial,
        "passed": summary["passed"],
        "samples": summary["samples"],
        "correct": summary["correct"],
        "validatedRecords": len(rows),
        "records": rows,
    }
    results.append(result)
    (root / "matrix-summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True), flush=True)
    if not summary["passed"]:
        print("STOP: failed case; no retry; remaining cases unattempted", flush=True)
        raise SystemExit(1)
