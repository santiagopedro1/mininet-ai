"""One declared prompt-tuning matrix through the real four-agent runtime."""

import hashlib
import json
import shutil
from copy import deepcopy
from datetime import UTC, datetime
from pathlib import Path

import yaml

from examples.diamond_recovery.diagnosis import evaluate_runtime
from mininet_ai.compiler import compile_experiment
from mininet_ai.substrates import FakeSubstrateRuntime
from mininet_ai.transports.http import HttpxJsonTransport
from tests.agents.test_bounded_evidence_schemas import validators

ENDPOINT = "http://10.10.10.152:9931"
TRIALS = (
    "healthy",
    "missing-flow-s2",
    "s1-s2",
    "s2-s4",
    "missing-flow-s1",
    "missing-flow-s3",
    "missing-flow-s4",
    "missing-flow-first-s2",
    "missing-flow-same-count-s2",
    "wrong-flow-s2",
    "wrong-cookie-s2",
    "reordered-flows",
    "unavailable",
)
root = Path("/tmp/opencode") / (
    "diagnosis-balanced-" + datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
)
root.mkdir(exist_ok=False)
shutil.copyfile(__file__, root / "evaluate.py")
transport = HttpxJsonTransport()


def observe(route, filename):
    value = transport.get_json(
        ENDPOINT + "/" + route,
        headers={"Accept": "application/json"},
        timeout_seconds=5,
        max_response_bytes=1_048_576,
    )
    (root / filename).write_text(
        json.dumps({"observedAt": datetime.now(UTC).isoformat(), "value": value}, indent=2)
        + "\n"
    )
    return value


def require_idle(filename):
    slots = observe("slots", filename)
    if not isinstance(slots, list) or len(slots) != 4 or any(
        slot.get("is_processing") is not False or slot.get("n_ctx") != 8192
        for slot in slots
    ):
        raise RuntimeError("Four idle 8192-context slots required; stop without retry")


print("Evidence:", root, flush=True)
require_idle("remote-preflight.json")
observe("health", "health.json")
props = observe("props", "props.json")
if props.get("model_alias") != "ggml-org/Kev-4B-GGUF":
    raise RuntimeError("Model identity changed; no inference sent")
source = Path("examples/diamond-recovery/experiment.yaml")
document = yaml.safe_load(source.read_text())
model = document["blueprints"][0]["model"]
model["name"] = "ggml-org/Kev-4B-GGUF"
model["parameters"] = {
    "endpoint": ENDPOINT,
    "expectedIdentity": {
        "repository": "ggml-org/Kev-4B-GGUF",
        "revision": "f4624b6bb7072f1bab726a622c1cad3f96030b9e",
        "artifact": "Kev-4B-Q8_0.gguf",
        "sha256": "7c2ebed90560522c2801389db482ac1dc4c36d828f201f6074c1d60e433948da",
    },
}
(root / "experiment.yaml").write_text(yaml.safe_dump(document, sort_keys=False))
plan = compile_experiment(root / "experiment.yaml")
scenario = plan.agents[0].decision_scenario
assert scenario is not None
expectations = scenario["localExpectations"]
(root / "conditions.json").write_text(
    json.dumps(
        {
            "endpoint": ENDPOINT,
            "plannedTrials": TRIALS,
            "scope": "prompt tuning on inspected failure; constructed local inputs, no OVS",
            "change": "scenario instructions and choice descriptions only",
            "sourceSHA256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "priorFailureArchive": "diagnosis-remote-native-20261030.tar.gz",
            "priorTuningFailure": "/tmp/opencode/diagnosis-flow-first-20261030T155458Z",
            "candidate": "balanced independent ports/flows checks, revision 2",
            "cadenceSeconds": 1,
            "deadlineSeconds": 5,
            "warmth": "startup-probed; cold unmeasured; server cache persists",
            "remoteHardwareBackendLaunch": "unavailable, not inferred from runner",
            "artifactHashVerification": "expected declaration; not remotely hashed",
            "retry": False,
            "stopOnFirstFailure": True,
        },
        indent=2,
    )
    + "\n"
)


class LocalSubstrate(FakeSubstrateRuntime):
    def __init__(self, trial):
        super().__init__()
        self.trial = trial

    def observe(self, run_id, query):
        result = super().observe(run_id, query)
        (target,) = query.targets
        local = deepcopy(expectations[target])
        if query.name == "ovs.port-state":
            if self.trial == "unavailable":
                return result.model_copy(update={"values": {target: None}})
            value = {"ports": [{"name": port, "state": "up"} for port in local["ports"]]}
            down = {
                "s1-s2": {"s1": "s1-eth2", "s2": "s2-eth1"},
                "s2-s4": {"s2": "s2-eth2", "s4": "s4-eth2"},
            }.get(self.trial, {})
            for port in value["ports"]:
                if port["name"] == down.get(target):
                    port["state"] = "down"
        elif query.name == "openflow.flows":
            if self.trial == "missing-flow-" + target:
                local["flows"].pop()
            if target == "s2":
                if self.trial == "missing-flow-first-s2":
                    local["flows"].pop(0)
                if self.trial == "missing-flow-same-count-s2":
                    local["flows"][-1] = deepcopy(local["flows"][0])
                if self.trial == "wrong-flow-s2":
                    local["flows"][0]["actions"] = "NORMAL"
                if self.trial == "wrong-cookie-s2":
                    local["flows"][-1]["cookie"] = "0xdead"
            if self.trial == "reordered-flows":
                local["flows"].reverse()
            value = {"switches": [{"name": target, "flows": local["flows"]}]}
        else:
            raise RuntimeError(f"Unexpected observation {query.name}")
        return result.model_copy(update={"values": {target: value}})


_, validator = validators()
results = []
for trial in TRIALS:
    require_idle("remote-before-" + trial + ".json")
    try:
        summary = evaluate_runtime(plan, LocalSubstrate(trial), root / trial)
    finally:
        require_idle("remote-after-" + trial + ".json")
    rows = []
    for line in (root / trial / "invocations.jsonl").read_text().splitlines():
        record = json.loads(line)
        execution = record["result"]["response"]["metadata"]["executionRecord"]
        validator.validate(execution)
        decision = execution["runtime"]["boundedDecision"]
        rows.append(
            {
                "agent": record["agentId"],
                "status": record["result"]["status"],
                "choice": decision.get("selectedChoice"),
                "decisionSeconds": decision.get("timings", {}).get("decisionSeconds"),
                "issue": record["result"].get("issue"),
            }
        )
    result = {
        "trial": trial,
        "passed": summary["passed"],
        "samples": summary["samples"],
        "correct": summary["correct"],
        "validatedRecords": len(rows),
        "records": rows,
    }
    results.append(result)
    (root / "matrix-summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(result, sort_keys=True), flush=True)
    if not summary["passed"]:
        print("STOP: failed case; no retry; remaining cases unattempted", flush=True)
        raise SystemExit(1)
